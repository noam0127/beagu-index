(() => {
  const status = document.getElementById('status');
  const capture = document.getElementById('capture');
  const retry = document.getElementById('retry');
  const imageFallback = document.getElementById('imageFallback');
  const loungeLink = document.getElementById('loungeLink');
  const copyFallback = document.getElementById('copyFallback');
  const home = 'https://baeguindex.com/';
  let imageUrl = null;

  // Preserve the existing challenge RPC and image-export behavior.
  async function prepareImage() {
    if (typeof html2canvas !== 'function') {
      throw new Error('이미지 생성 기능을 불러오지 못했습니다.');
    }
    if (document.fonts?.ready) await document.fonts.ready;
    const canvas = await html2canvas(document.getElementById('certificate'), {
      scale: 2,
      backgroundColor: '#ffffff',
      logging: false
    });
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
    if (!blob) throw new Error('인증 이미지를 생성하지 못했습니다.');
    if (imageUrl) URL.revokeObjectURL(imageUrl);
    imageUrl = URL.createObjectURL(blob);
    imageFallback.href = imageUrl;
    capture.disabled = false;
    status.textContent = '인증 이미지 준비 완료. 저장 버튼을 눌러주세요.';
  }

  async function join() {
    capture.disabled = true;
    retry.hidden = true;
    imageFallback.hidden = true;
    status.textContent = '참여 순번을 확인하고 있습니다.';
    try {
      if (!window.beaguVisitor) {
        throw new Error('브라우저 저장 공간을 허용한 뒤 다시 접속해 주세요.');
      }
      const { data, error } = await supabaseClient.rpc('beagu_join_challenge', {
        p_visitor: window.beaguVisitor
      });
      const n = Number(data);
      if (error || !Number.isSafeInteger(n) || n < 1) {
        throw new Error('참여 기록 연결을 확인하지 못했습니다. 다시 시도해 주세요.');
      }
      document.getElementById('participantNo').textContent = n.toLocaleString('ko-KR') + '번째';
      status.textContent = '인증 이미지를 준비하는 중입니다.';
      await prepareImage();
    } catch (e) {
      status.textContent = e?.message || '일시적인 오류가 발생했습니다.';
      retry.hidden = false;
    }
  }

  capture.addEventListener('click', () => {
    if (!imageUrl) {
      status.textContent = '아직 인증 이미지가 준비되지 않았습니다.';
      return;
    }
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = '2026-배구지수-챌린지.png';
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    link.remove();
    imageFallback.hidden = false;
    status.textContent = '이미지 저장을 요청했습니다. 다운로드 폴더를 확인해 주세요.';
  });

  // Copy the home URL only when the teacher chooses the lounge step.
  // A plain anchor handles opening the lounge, so popup blocking does not affect navigation.
  loungeLink.addEventListener('click', () => {
    if (!navigator.clipboard?.writeText) {
      copyFallback.hidden = false;
      return;
    }
    try {
      navigator.clipboard.writeText(home).then(
        () => { copyFallback.hidden = true; },
        () => { copyFallback.hidden = false; }
      );
    } catch (_) {
      copyFallback.hidden = false;
    }
  });

  retry.addEventListener('click', join);
  window.addEventListener('pagehide', () => {
    if (imageUrl) URL.revokeObjectURL(imageUrl);
  }, { once: true });
  join();
})();
